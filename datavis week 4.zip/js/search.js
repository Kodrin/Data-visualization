function openNav() {
  document.getElementById("searchBar").style.display = "block";
}

function closeNav() {
  document.getElementById("searchBar").style.display = "none";
}
