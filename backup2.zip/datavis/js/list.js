function generateListView(){
  console.log(countryNames);
  for(let i =0; i<countryNames.length; i++ ){
    let divCity = document.createElement("div");
    divCity.className = "city";
    divCity.textContent = countryNames[i];
    document.getElementById("listview").appendChild(divCity);
  }
  document.getElementById("listview").style.overflowY = "scroll";
}
